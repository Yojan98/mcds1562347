<?php $__env->startSection('title', 'Consultar Categoria'); ?>

<?php $__env->startSection('content'); ?>

<h1 class="text-center"> <i class="fa fa-search">Consultar Categoria</i></h1>
<hr>
<ul class="breadcrumb">
	<li><a href="<?php echo e(url('category')); ?>">Módulo Categoria</a></li>
	<li class="active">Consultar Categoria</li>
</ul>
<hr>	
<table class="table table-striped table-bordered">
	<tr>
		<th>Id:</th>
		<td><?php echo e($cat->id); ?></td>
	</tr>
	<tr>
		<th>Nombre de Usuario:</th>
		<td><?php echo e($cat->name); ?></td>
	</tr>
	
	<tr>
		<th>Creado:</th>
		<?php 
			\Carbon\Carbon::setLocale(config('app.locale'));
			$hoy = \Carbon\Carbon::now();
			$fca = \Carbon\Carbon::parse($cat->created_at);
		?>
		<td><?php echo e($fca->diffForHumans($hoy)); ?></td>
	

</table>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts-base.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>