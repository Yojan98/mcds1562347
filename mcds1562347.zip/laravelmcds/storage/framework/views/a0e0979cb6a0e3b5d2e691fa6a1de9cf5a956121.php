<?php $__env->startSection('content'); ?>

        
            <div class="panel panel-info">
                <div class="panel-heading text-center"><i class="fa fa-user-secret fa-2x"></i><strong class="lead  ">ADMINISTRADOR: </strong></div>

                <div class="panel-body">
                    <div class="row">
                        <div class="col-md-8">
                            <div class="list-group">
                                
                                <div class="list-group-item list-group-item-warning">
                                  <strong>Nombre de Usuario:</strong>  <?php echo e(Auth::user()->username); ?>

                                </div>
                                <br>
                                
                                <div class="list-group-item list-group-item-info">
                                  <strong>Nombre Completo:</strong>  <?php echo e(Auth::user()->firstname); ?> <?php echo e(Auth::user()->lastname); ?>

                                </div>
                                                              
                                <div class="list-group-item list-group-item-default">
                                  <strong>Correo Electrónico:</strong>    <?php echo e(Auth::user()->email); ?> 
                                </div>
                               
                                <div class="list-group-item list-group-item-info">
                                    <strong>País:</strong>   <?php echo e(Auth::user()->country); ?> 
                                </div>
                                
                                <div class="list-group-item list-group-item-default">
                                  <strong>Número telefónico:</strong>    <?php echo e(Auth::user()->phonenumber); ?> 
                                </div>
                                
                                <div class="list-group-item list-group-item-info">
                                    <strong>Fecha Nacimiento:</strong>  <?php echo e(Auth::user()->birthdate); ?> 
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <img src="<?php echo e(asset(substr(Auth::user()->photo, 7))); ?>" class="img-thumbnail" width="200px">          
                        </div>
                </div>
            </div>
        </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts-base.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>