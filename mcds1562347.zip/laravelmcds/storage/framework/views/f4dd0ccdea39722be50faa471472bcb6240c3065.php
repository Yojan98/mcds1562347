<?php $__env->startSection('content'); ?>

        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading"><strong>Bienvenido: </strong><?php echo e(Auth::user()->username); ?></div>

                <div class="panel-body">
                    Usted esta registrado como
                    <?php if(Auth::user()->role == "Admin"): ?>
                        Administrador
                    <?php else: ?>
                        Editor
                    <?php endif; ?>
                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts-base.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>