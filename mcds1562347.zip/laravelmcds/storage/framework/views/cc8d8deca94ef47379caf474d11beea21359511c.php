<?php $__env->startSection('title', 'Consultar Usuarios'); ?>

<?php $__env->startSection('content'); ?>

<h1 class="text-center"> <i class="fa fa-search">Consultar Usuarios</i></h1>
<hr>
<ul class="breadcrumb">
	<li><a href="<?php echo e(url('user')); ?>">Módulo Usuario</a></li>
	<li class="active">Consultar Usuario</li>
</ul>
<hr>	
<table class="table table-striped table-bordered">
	<tr>
		<th>Id:</th>
		<td><?php echo e($user->id); ?></td>
	</tr>
	<tr>
		<th>Nombre de Usuario:</th>
		<td><?php echo e($user->username); ?></td>
	</tr>
	<tr>
		<th>Nombre Completo:</th>
		<td><?php echo e($user->firstname); ?> <?php echo e($user->lastname); ?></td>
	</tr>
	<tr>
		<th>Correo Electrónico:</th>
		<td><?php echo e($user->email); ?></td>
	</tr>
	<tr>
		<th>Rol:</th>
		<td><?php echo e($user->role); ?></td>
	</tr>
	<tr>
		<th>Foto:</th>
		<td><img src="<?php echo e(asset(substr($user->photo, 7))); ?>" width="96px" data-img="<?php echo e(asset(substr($user->photo, 7))); ?>" style="cursor: zoom-in;"></td>
	</tr>
	<tr>
		<th>Color:</th>
		<td><button class="btn" style="background-color:<?php echo e($user->colortheme); ?>; color: white;"><i class="fa fa-paint-brush"></i></button></td>
	</tr>
	<tr>
		<th>País:</th>
		<td><?php echo e($user->country); ?></td>
	</tr>
	<tr>
		<th>Número Telefónico:</th>
		<td><?php echo e($user->phonenumber); ?></td>
	</tr>
	<tr>
		<th>Fecha Nacimiento:</th>
		<?php 
			\Carbon\Carbon::setLocale(config('app.locale'));
			$hoy = \Carbon\Carbon::now();
			$fna = \Carbon\Carbon::parse($user->birthdate);
		?>
		<td> <?php echo e($user->birthdate); ?> | <?php echo e($hoy->diffInYears($fna)); ?> Años</td>
	</tr>
	<tr>
		<th>Creado:</th>
		<?php 
			$fca = \Carbon\Carbon::parse($user->created_at);
		?>
		<td><?php echo e($fca->diffForHumans($hoy)); ?></td>
	</tr>

</table>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts-base.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>