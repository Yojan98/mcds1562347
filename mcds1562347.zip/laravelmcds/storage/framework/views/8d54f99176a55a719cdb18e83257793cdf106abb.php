<?php $__env->startSection('title', 'Adiccionar Categorias'); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
	<div class="col-md-6 col-md-offset-3">

<h1 class="text-center"> <i class="fa fa-user">Adiccionar Categorias</i></h1>
<hr>
<ul class="breadcrumb">
	<li><a href="<?php echo e(url('category')); ?>">Módulo Categorias</a></li>
	<li class="active">Insertar Categoria</li>
</ul>
<hr>
<?php if(count($errors) > 0): ?>
	<div class="alert alert-danger">
		<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<li> <?php echo e($message); ?> </li>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>
<?php endif; ?>	
<form action="<?php echo e(url('category')); ?>" method="post" >
	<?php echo csrf_field(); ?>

	
	<div class="form-group">
		<input type="text" name="name" class="form-control" placeholder="Nombre de categoria" value="<?php echo e(old('name')); ?>">
	</div>

	

	<div class="form-group">
	<button type="submit" class="btn btn-success">
			<i class="fa fa-save"></i>Guardar

	</button>

	<button type="reset" class="btn btn-default">
			<i class="fa fa-repeat"></i>Limpiar

	</button>
</form>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts-base.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>