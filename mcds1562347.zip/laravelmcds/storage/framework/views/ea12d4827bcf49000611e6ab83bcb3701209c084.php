<?php $__env->startSection('content'); ?>
        <div class="row">
            <div class="col-md-6 col-md-offset-3">
            <div class="panel panel-default">
                <div class="panel-heading"><i class="fa fa-lock fa-2x"></i> <strong>INGRESO</strong></div>

                <div class="panel-body">
                    <?php if(count($errors) > 0): ?>
                    <div class="alert alert-danger">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li> <?php echo e($message); ?> </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <?php endif; ?>  
                    <form method="POST" action="<?php echo e(route('login')); ?>">
                        <?php echo e(csrf_field()); ?>


                        <div class="form-group">                            
                            <input id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" placeholder="Correo Electrónico" required autofocus>

                       
                        </div>

                        <div class="form-group">
                          <input id="password" type="password" class="form-control" name="password" placeholder="Contraseña" required>


                        </div>

                        <div class="form-group">
                                <div class="checkbox">
                                    <label>
                                        <input type="checkbox" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>> Recordarme
                                    </label>
                            </div>
                        </div>

                        <div class="form-group">
                                <button type="submit" class="btn btn-primary">
                                    Ingresar
                                </button>

                                <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
                                    ¿Olvido su contraseña?
                                </a>
                            </div>
                    </form>
                </div>
            </div>
        </div>     
    </div>    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts-base.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>