<?php $__env->startSection('title', 'Módulo Usuarios'); ?>

<?php $__env->startSection('content'); ?>

				<h1 class="text-center"> <i class="fa fa-user"></i>Módulo Usuarios |
				<span class="badge"> <?php echo e($count); ?> Usuarios</span>
			    </h1>
				<hr>
				<a href="<?php echo e(url('user/create')); ?>" class="btn btn-success">
					<i class="fa fa-plus"></i>Usuario
				</a>
				<a href="<?php echo e(url('userspdf')); ?>" class="btn btn-info"><i class="fa fa-file-pdf"></i></a>
				<a href="<?php echo e(url('')); ?>" class="btn btn-info"><i class="fa fa-file-excel"></i></a>

				
				<table class="table table-striped table-hover table-bordered">
					<hr>
					<thead>
						<tr>
							<th> Nombre Usuario </th>
							<th> Correo Electronico</th>
							<th> Rol </th>
							<th> Foto </th>
							<th> Acciones</th>
						</tr>
					</thead>
					<tbody>
						<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

						
						<tr>
							<td>  <?php echo e($user->username); ?></td>
							<td>  <?php echo e($user->email); ?></td>
							<td>  <?php echo e($user->role); ?></td>
							<td> <img src="<?php echo e(asset(substr($user->photo, 7 ))); ?>" width="35px" ></td>
							<td>
								<a href="<?php echo e(url('user/'.$user->id)); ?>" class="btn btn-primary"> <i class="fa fa-search"></i> </a>
								<a href="<?php echo e(url('user/'.$user->id.'/edit')); ?>" class="btn btn-success"> <i class="fa fa-pencil-alt"></i></a>

								<form action="<?php echo e(url('user/'.$user->id)); ?>" method="post" style="display: inline-block;">
									<?php echo e(method_field('delete')); ?>

									<?php echo csrf_field(); ?>

									<button type="button" class="btn btn-danger btn-delete"><i class="fa fa-trash"></i></button>
								</form>

								<!-- <a href="" class="btn btn-danger">  <i class="fa fa-trash"></i> </a> -->
							</td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
					<tfoot>
						<tr class="text-center">
							<td colspan="5"> <?php echo e($users->links()); ?> </td>
						</tr>
					</tfoot>
				
			   </table>
<?php $__env->stopSection(); ?>			   
			
<?php echo $__env->make('layouts-base.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>