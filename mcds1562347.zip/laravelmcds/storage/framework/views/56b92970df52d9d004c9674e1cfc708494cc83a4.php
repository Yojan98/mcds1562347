<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Reporte PDF</title>
	<style>
		body{
			font-family: Helvetica;
			
		}
		table {
			border-collapse: collapse;			
		}
		table th,
		table td {
			font-size: 14px !important;
		}
		table th {
			background-color: gray;
			color: white;
			text-align: center
		}
		table td {
			border: 1px solid silver;
			padding: 10px;
		}
	</style>
</head>
<body>
	

<table>
	<thead>
		<tr>
			<th> ID </th>
			<th> Nombre Completo </th>
			<th> Correo Electrónico </th>
			<th> Rol </th>
			<th> País </th>
			<th> Teléfono </th>
			<th> Fecha Nacimiento </th>

		</tr>
	</thead>
	<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td> <?php echo e($user->id); ?> </td>
			<td> <?php echo e($user->firstname); ?> <?php echo e($user->lastname); ?> </td>
			<td> <?php echo e($user->email); ?> </td>
			<td> <?php echo e($user->role); ?> </td>
			<td> <?php echo e($user->country); ?> </td>
			<td> <?php echo e($user->phonenumber); ?> </td>
			<td> <?php echo e($user->birthdate); ?> </td>
			
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
</body>
</html>