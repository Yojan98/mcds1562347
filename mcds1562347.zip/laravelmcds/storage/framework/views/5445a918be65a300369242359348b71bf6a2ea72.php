<?php $__env->startSection('title', 'Módulo Categorias'); ?>

<?php $__env->startSection('content'); ?>

				<h1 class="text-center"> <i class="fa fa-user"></i>Módulo Categorias |
				<span class="badge"> <?php echo e($count); ?> Categorias</span>
			    </h1>
				<hr>
				<a href="<?php echo e(url('category/create')); ?>" class="btn btn-success">
					<i class="fa fa-plus"></i>Categoria
				</a>
				
				<table class="table table-striped table-hover table-bordered">
					<hr>
					<thead>
						<tr>
							<th> ID</th>
							<th> Nombre Categoria </th>
							<th> Acciones</th>
						</tr>
					</thead>
					<tbody>
						<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

						
						<tr>
							<td>  <?php echo e($cat->id); ?></td>
							<td>  <?php echo e($cat->name); ?></td>
							<td>
								<a href="<?php echo e(url('category/'.$cat->id)); ?>" class="btn btn-primary"> <i class="fa fa-search"></i> </a>
								<a href="<?php echo e(url('category/'.$cat->id.'/edit')); ?>" class="btn btn-success"> <i class="fa fa-pencil"></i></a>

								<form action="<?php echo e(url('category/'.$cat->id)); ?>" method="post" style="display: inline-block;">
									<?php echo e(method_field('delete')); ?>

									<?php echo csrf_field(); ?>

									<button type="button" class="btn btn-danger btn-delete"><i class="fa fa-trash"></i></button>
								</form>

								<!-- <a href="" class="btn btn-danger">  <i class="fa fa-trash"></i> </a> -->
							</td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
					<tfoot>
						<tr class="text-center">
							<td colspan="3"> <?php echo e($categories->links()); ?> </td>
						</tr>
					</tfoot>
				
			   </table>
<?php $__env->stopSection(); ?>			   
			
<?php echo $__env->make('layouts-base.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>