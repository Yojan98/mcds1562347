<?php $__env->startSection('title', 'Bienvenidos Laravel'); ?>
<?php $__env->startSection('content'); ?>
    <h1> Bienvenidos LARAVEL</h1>
    <p class="lead">
        Especialización Tecnológica en Metodologías de Calidad para el desarrollo de software
    </p>
    <hr>
    <div class="row">
        <div class="col-md-12">
        	<div class="row">
        	<?php $__currentLoopData = $arts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $art): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        		<div class="col-md-4">
        		<div class="thumbnail">
        			<img src="<?php echo e(asset(substr($art->image, 7))); ?>">
        			<div class="caption">
        				<h3> <?php echo e($art->name); ?></h3>
        				<small class="label label-primary"> <?php echo e($art->category->name); ?> </small>
        				<p>
        					<?php echo e($art->content); ?>

        				</p>
        				<small class="label label-danger"> <?php echo e($art->user->username); ?></small>
        				</div>
        			</div>
        		</div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>  
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts-base.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>