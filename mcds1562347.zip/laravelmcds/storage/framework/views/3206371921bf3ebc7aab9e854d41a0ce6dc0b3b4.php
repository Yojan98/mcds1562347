<?php $__env->startSection('content'); ?>
<?php if(count($errors) > 0): ?>
<div class="alert alert-danger">
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li> <?php echo e($message); ?> </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php endif; ?>
<div class="panel panel-default">
    <div class="panel-heading"><i class="fa fa-address-card fa-2x"></i> <strong>REGISTRARSE</strong></div>

    <div class="panel-body">
        <form  method="POST" enctype="multipart/form-data" action="<?php echo e(route('register')); ?>">
            <?php echo e(csrf_field()); ?>


            <div class="form-group">
                <input type="text" name="username" class="form-control" placeholder="Nombre de usuario" value="<?php echo e(old('username')); ?>">
            </div>

            <div class="form-group">
                <input type="text" name="firstname" class="form-control" placeholder="Nombres" value="<?php echo e(old('firstname')); ?>">
            </div>

            <div class="form-group">
                <input type="text" name="lastname" class="form-control" placeholder="Apellidos" value="<?php echo e(old('lastname')); ?>">
            </div>

            <div class="form-group">
                <input type="text" name="email" class="form-control" placeholder="Correo Eléctronico" value="<?php echo e(old('email')); ?>">
            </div>

            <div class="form-group">
                <small>Seleccione una foto </small>
                <input type="file" name="photo" accept="image/*"  class="form-control">

            </div>

            <div class="form-group">
                <select name="role" class="form-control">
                    <option value="">Seleccione un rol</option>
                    <option value="Admin" <?php echo e(old('role') == 'Admin' ? 'selected' : ''); ?>>Administrador</option>
                    <option value="Editor" <?php echo e(old('role') == 'Editor' ? 'selected' : ''); ?>>Editor </option>
                </select>
            </div>

            <div class="form-group">
                <input type="password" name="password" class="form-control" placeholder="Contraseña">
            </div>

            <div class="form-group">
                <input type="password" name="confirm_password" class="form-control" placeholder="Confirmar contraseña">
            </div>

            <div class="form-group">
                <input type="color" name="colortheme" class="form-control" placeholder="Color" value="<?php echo e(old('colortheme')); ?>">
                <small>El color debe estar en hexadecimal</small>
            </div>

            <div class="form-group">
                <input type="text" name="country" class="form-control" placeholder="País" value="<?php echo e(old('country')); ?>">
            </div>

            <div class="form-group">
                <input type="text" name="phonenumber" class="form-control" placeholder="Número Telefónico" value="<?php echo e(old('phonenumber')); ?>">
            </div>

            <div class="form-group">
                <input type="text" name="birthdate" class="form-control" placeholder="Fecha Nacimiento" value="<?php echo e(old('birthdate')); ?>">
            </div>

            <div class="form-group">
                <button type="submit" class="btn btn-primary">
                    Registrar
                </button>
            </div>
        </form> 
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts-base.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>